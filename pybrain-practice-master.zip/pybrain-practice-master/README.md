PyBrain practice
================

See [http://fastml.com/pybrain-a-simple-neural-networks-library-in-python/](http://fastml.com/pybrain-a-simple-neural-networks-library-in-python/) for description.

